package it.nextdevs.u5s1g1l;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class U5s1g1lApplicationTests {

	@Test
	void contextLoads() {
	}

}
