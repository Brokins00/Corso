package it.nextdevs.u5s1g1l;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class U5s1g1lApplication {

	public static void main(String[] args) {
		SpringApplication.run(U5s1g1lApplication.class, args);
	}

}
